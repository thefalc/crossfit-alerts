(function() {
	console.log("CFA init");
	setTimeout(function() {
		var url = document.location.href;
		//console.log(url);
		if (url.indexOf("/athlete/") != -1) {
			var titleElement = document.getElementById("page-title");
			if (titleElement) {
				var titleText = titleElement.innerHTML;
				if (titleText.indexOf("Athlete: ") == 0) {
					addLink(titleElement, titleText.substr(9), 0);
				}
			}
		} else if ((url.indexOf("/affiliate/") != -1) || 
					(url.indexOf("/team/") != -1) || 
					(url.indexOf("/scores/") != -1)) {
			var anchors = document.getElementsByTagName("a");
			if (anchors && (anchors.length > 0)) {
				//console.log("Parsing " + anchors.length + " anchors...");
				var isScores = (url.indexOf("/scores/") != -1);
				var placement = (isScores ? 1 : 2);
				for (var i = 0; i < anchors.length; i++) {
					var a = anchors[i];
					if (a.href.indexOf("/athlete/") != -1) {
						var innerText = a.innerText.trim();
						//console.log(a.href + " - '" + innerText + "', " + innerText.length);
						if ((innerText.length > 3) && (innerText.indexOf("#") == -1)) {
							addLink(a, innerText, placement);
						}
					}
				}
			}
		}
		
	}, 500);	
	
	function createLink(athleteName) {
		var link = document.createElement("a");
		link.target = "CrossFitAlerts";
		link.href = "http://www.crossfitalerts.com/?q=" + encodeURIComponent(athleteName);
		link.title = "CrossFit Alerts for " + athleteName;
		link.className = "cfAlertsLink";
		
		var img = document.createElement("img");
		var imgUrl = chrome.extension.getURL("clock.png");
		img.src = imgUrl;
		img.alt = "CrossFit Alerts for " + athleteName;
		img.className = "cfAlertsImage";
		link.appendChild(img);
		
		return link;
	}
	
	function addLink(element, athleteName, placement) {
		//console.log("Adding link for " + athleteName);
		var link = createLink(athleteName);
		var parent = element.parentNode;
		parent.style.position = "relative";
		link.style.position = "absolute";
		link.style.top = "50%";
		link.style.marginTop = "-10px";
		if (placement == 0) {
			// to the right of the athlete name
			link.style.left = (element.offsetWidth + 10) + "px";
			link.style.padding = "2px 4px";
			link.style.backgroundColor = "white";
		} else if (placement == 1) {
			// aligned outside the right edge
			link.style.right = "-18px";
		} else if (placement == 2) {
			// aligned on the right side
			link.style.right = "5px";
		}
		
		parent.appendChild(link);
	}
	
})();
